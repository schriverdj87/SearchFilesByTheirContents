﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;

namespace SearchByContents
{
    /* Sauce
     * https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/file-system/how-to-iterate-through-a-directory-tree
     * https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/file-system/how-to-read-a-text-file-one-line-at-a-time
     * https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/file-system/how-to-write-to-a-text-file
     * https://stackoverflow.com/questions/3546016/how-to-copy-data-to-clipboard-in-c-sharp
     */
    class Program
    {
        private string lookinhere = "";
        private string lookforthis = "";
        private string lastresults;
        private List<string> donotbother = new List<string>() { "png","jpg","jpeg","db","mp3","wav" };
        private string reportsdirectory = "reports";
        public Program()
        {

        }

        public void run()
        {


            Console.WriteLine("Welcome to Search By Contents");

            bool isRunning = true;

            while (isRunning)
            {
                Console.WriteLine("\n---------");
                Console.WriteLine("Directory: " + lookinhere);
                Console.WriteLine("Search For: " + lookforthis);
                Console.WriteLine("---------");

                Console.WriteLine("Please make a selection:");
                Console.WriteLine("0: Quick Run");
                Console.WriteLine("1: Set Directory");
                Console.WriteLine("2: Set What to Look For");
                Console.WriteLine("3: Search");
                Console.WriteLine("4: Export Last Results");
                Console.WriteLine("q: Quit");
                string input = Console.ReadLine();

                if (input == "0")
                {
                    SetLookInHere();
                    SetLookForThis();
                    Search();
                }

                if (input == "1")
                {
                    SetLookInHere();
                }

                if (input == "2")
                {
                    SetLookForThis();
                }

                if (input == "3")
                {
                    Search();
                }

                if (input == "4")
                {
                   WriteFile();
                }

                

                if (input == "q")
                {
                    isRunning = false;
                    Console.WriteLine("Thank you! Come again!");
                }

                
            }

        }


        public async Task WriteFile()
        {
            DateTime thisMoment = DateTime.Now;
            string fileName = thisMoment.Year.ToString() + "_" + thisMoment.Month.ToString() + "_" + thisMoment.Day.ToString() + " " + thisMoment.Hour.ToString() + "_" + thisMoment.Minute.ToString() + "_" + thisMoment.Second.ToString() + ".txt";

            if (!Directory.Exists(reportsdirectory))
            {
                Directory.CreateDirectory(reportsdirectory);
            }

            await File.WriteAllTextAsync(reportsdirectory+"/"+fileName, lastresults);
            Console.WriteLine("File exported to "+fileName+". Check the " + reportsdirectory + " directory in this application's folder");
        }

        public void SetLookForThis()
        {
            Console.WriteLine("Enter Search Term:");
            lookforthis = Console.ReadLine(); 
        }


        public void SetLookInHere()
        {
            Console.WriteLine("Enter Search Location:");
            lookinhere = Console.ReadLine();
        }

        public void Search()
        {
            Search(lookinhere, lookforthis);
        }
        public void Search(string location, string term)
        {
            //System.IO.SearchOption.AllDirectories;

            //Get a flattened directory
            DirectoryInfo poop = new DirectoryInfo(location);
            List<DirectoryInfo> flatDirectory = new List<DirectoryInfo>();
            List<FileInfo> files = new List<FileInfo>();
            flatDirectory.Add(new DirectoryInfo(location));
           

            try
            {
                flatDirectory[0].GetDirectories();
            }
            catch (System.IO.DirectoryNotFoundException)
            {
                Console.WriteLine("Cannot find directory!");
            }



            //For each item in the flat directory
            for (int a = 0; a < flatDirectory.Count; a++)
            {
                DirectoryInfo[] currentDirectories = flatDirectory[a].GetDirectories();

                //For each sub directory 
                for (int b = 0; b < currentDirectories.Length; b++)
                {
                    DirectoryInfo toAdd = currentDirectories[b];

                    //If it isn't already in there
                    if (flatDirectory.Contains(toAdd) == false)
                    {
                        flatDirectory.Add(currentDirectories[b]);
                       
                    }
                }
            }

            //For each file in each folder

            for (int b = 0; b < flatDirectory.Count; b++)
            {
                FileInfo[] currentFiles = flatDirectory[b].GetFiles();

                for (var c = 0; c < currentFiles.Length; c++)
                {
                    FileInfo toAdd = currentFiles[c];
                    if (ValidFile(toAdd))
                    {
                        files.Add(toAdd);
                    }
                }

            }

            lastresults = "Searching for: \"" + lookforthis + "\" in " + lookinhere +"\n----------------------";

            //Read each file line by line
            for (int d = 0; d < files.Count; d++)
            {
                string rawresults = CheckForThis(files[d], lookforthis);

                if (rawresults.Length != 0)
                {
                    string result = files[d].FullName + " at lines: " + rawresults;
                    lastresults = lastresults + "\n" +result;
                    
                }

            }

            Console.WriteLine(lastresults);




        }

        //Checks if a file has a particular string within.
        public string CheckForThis(FileInfo checkthis,string forthis)
        {
            string toSend = "";


            string leFile = checkthis.FullName;
            string ln = "";
            int lncurrent = 1;


            StreamReader truefile = new StreamReader(@leFile);

            while ((ln = truefile.ReadLine()) != null)
            {
                if (ln.ToLower().Contains(forthis.ToLower()))
                {
                    if (toSend.Length != 0) { toSend = toSend + ","; }

                    toSend = toSend + lncurrent.ToString();

                }

                lncurrent++;
            }

                truefile.Close();


            return toSend;
        }

        //Checks if the file's extension is not in the donotbother list.
        public bool ValidFile(FileInfo checkme)
        {
            

            string rawpath = checkme.FullName;
            string[] splitrawpath = rawpath.Split(".");
            string extension = splitrawpath[splitrawpath.Length - 1];

            if (donotbother.Contains(extension))
            {
                return false;
            }


            return true;
        }

        //Iterates through the list one at a time
        public void ReadList(List<DirectoryInfo> poop)
        {
            for (var a = 0; a < poop.Count; a++)
            {
                Console.WriteLine(poop[a]);
            }
        }

        static void Main(string[] args)
        {

            Program core = new Program();
            core.run();
        }
    }
}
