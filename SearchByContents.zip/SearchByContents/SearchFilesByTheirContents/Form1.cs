﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading.Tasks;

namespace SearchFilesByTheirContents
{
    public partial class Form1 : Form
    {

        private string lookinhere = "";
        private string lookforthis = "";
        private string lastresults = "";
        private List<string> donotbother = new List<string>() { "png", "jpg", "jpeg", "db", "mp3", "wav","gif","zip" };
        private string reportsdirectory = "reports";
        private string compareDir1 = "";
        private string compareDir2 = "";
        public static string NONE = "NONE";

        public Form1()
        {
            InitializeComponent();
            SetClear();

        }

        private void SetError(string to)
        {
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = to;
        }

        private void SetWin(string to)
        {
            lblMessage.ForeColor = Color.Green;
            lblMessage.Text = to;
        }

        private void SetClear()
        {
            lblMessage.Text = "";

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            lookinhere = txtSearch.Text;
            lookforthis = txtForThis.Text;

            
            if (lookinhere.Length == 0 || Directory.Exists(lookinhere) == false)
            {
                SetError("Please enter a valid file location");
            }
            else if (lookforthis.Length == 0)
            {
                SetError("Please enter text to look for");
            }
            else
            {
                SetWin("Searching...");
                Search();
                txtOutput.Text = lastresults;
                SetClear();
            }
        }
        //DEPRECATED 
        public async Task WriteFile()
        {
            DateTime thisMoment = DateTime.Now;
            string fileName = thisMoment.Year.ToString() + "_" + thisMoment.Month.ToString() + "_" + thisMoment.Day.ToString() + " " + thisMoment.Hour.ToString() + "_" + thisMoment.Minute.ToString() + "_" + thisMoment.Second.ToString() + ".txt";

            if (!Directory.Exists(reportsdirectory))
            {
                Directory.CreateDirectory(reportsdirectory);
            }

           
            System.IO.File.WriteAllText(reportsdirectory + "/" + fileName, lastresults);
            SetWin("File exported to " + fileName + ". Check the " + reportsdirectory + " directory in this application's folder");
        }

        //Simple file writing method.
        public async Task WriteFile(string tothispath,string contents)
        {
            System.IO.File.WriteAllText(tothispath, contents);
            SetWin("File Created");
        }

        public void Compare(string location1, string location2)
        {
            lastresults = "Comparing " + location1 + " with " + location2;
            lastresults = lastresults + Environment.NewLine + "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=";
            List<DirectoryInfo> Dir1 = GetFlatDirectory(location1);
            List<DirectoryInfo> Dir2 = GetFlatDirectory(location2);
      
            
            List<FileInfo> Files1 = GetFlatFileList(Dir1);
            List<FileInfo> Files2 = GetFlatFileList(Dir2);



            lastresults = lastresults + Environment.NewLine + "Folders exclusive to " + location1 + Environment.NewLine;


            List<String> Dir1Strings = GetFlatDirectoryStrings(Dir1, location1);
            List<String> Dir2Strings = GetFlatDirectoryStrings(Dir2, location2);

            lastresults = lastresults + ToFlatString(ExclusiveToParam1(Dir1Strings,Dir2Strings));

            lastresults = lastresults + Environment.NewLine + "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=" ;

            lastresults = lastresults + Environment.NewLine + "Folders exclusive to " + location2 + Environment.NewLine;

            lastresults = lastresults + ToFlatString(ExclusiveToParam1(Dir2Strings, Dir1Strings));

            lastresults = lastresults + Environment.NewLine + "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=" ;

            lastresults = lastresults + Environment.NewLine + "Files exclusive to " + location1 + Environment.NewLine;

            List<String> Files1Strings = GetFlatFileListStrings(Files1, location1);
            List<String> Files2Strings = GetFlatFileListStrings(Files2, location2);

            lastresults = lastresults + ToFlatString(ExclusiveToParam1(Files1Strings, Files2Strings));

            lastresults = lastresults + Environment.NewLine + "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=";
            lastresults = lastresults + Environment.NewLine + "Files exclusive to " + location2 + Environment.NewLine;


            lastresults = lastresults + ToFlatString(ExclusiveToParam1(Files2Strings, Files1Strings));

            lastresults = lastresults + Environment.NewLine + "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=";
            lastresults = lastresults + Environment.NewLine + "Differences" + Environment.NewLine;

            List<String> MutualFiles = ContainsMutual(Files1Strings, Files2Strings);

         

            for (var a = 0; a < MutualFiles.Count; a++)
            {
                if (ValidFile(MutualFiles[a]))
                {
                    String ComparTXTS = ImportAndCompareTextsString(location1 + MutualFiles[a],location2 + MutualFiles[a]);
                    if (ComparTXTS == NONE)
                    {
                        continue;
                    }

                    lastresults = lastresults + Environment.NewLine + MutualFiles[a] +  ComparTXTS;


                }
            }


        }




        public List<DirectoryInfo> GetFlatDirectory (string location)
        {
            List<DirectoryInfo> toSend = new List<DirectoryInfo>();
            toSend.Add(new DirectoryInfo(location));

            for (int a = 0; a < toSend.Count; a++)
            {
                DirectoryInfo[] currentDirectories = toSend[a].GetDirectories();

                //For each sub directory 
                for (int b = 0; b < currentDirectories.Length; b++)
                {
                    DirectoryInfo toAdd = currentDirectories[b];

                    //If it isn't already in there
                    if (toSend.Contains(toAdd) == false)
                    {
                        toSend.Add(currentDirectories[b]);

                    }
                }
            }

            return toSend;
        }

        public List<String> GetFlatDirectoryStrings (List<DirectoryInfo> convertme, string excludeme)
        {
            List<String> toSend = new List<String>();

            for (int a = 0; a < convertme.Count; a++)
            {
                String toPut = convertme[a].FullName.Replace(excludeme, "");
                //Check if it's already there first?
                toSend.Add(toPut);
            }

            return toSend;
        }

        public List<String> ExclusiveToParam1(List<String> l1, List<String> l2)
        {
            List<String> toSend = new List<string>();

            for (int a = 0; a < l1.Count; a++)
            {
                if (l2.Contains(l1[a]) == false)
                {
                    toSend.Add(l1[a]);
                }
            }

            return toSend;
        }

        public List<String> ContainsMutual(List<String> l1, List<String> l2)
        {
            List<String> toSend = new List<string>();

            for (int a = 0; a < l1.Count; a++)
            {
                if (l2.Contains(l1[a]))
                {
                    toSend.Add(l1[a]);
                }
            }

            for (int b = 0; b < l2.Count; b++)
            {
                if (l1.Contains(l2[b]) && toSend.Contains(l2[b]) == false)
                {
                    toSend.Add(l2[b]);
                }
            }

            return toSend;
        }

        public String ToFlatString (List<String> grindme)
        {
            String toSend = "";

            for (int a = 0; a < grindme.Count; a++)
            {
                toSend = toSend + Environment.NewLine + grindme[a];
            }

            return toSend;


        }

        public List<FileInfo> GetFlatFileList(List<DirectoryInfo> checkme)
        {

            List<FileInfo> toSend = new List<FileInfo>();

            for (int b = 0; b < checkme.Count; b++)
            {
                FileInfo[] currentFiles = checkme[b].GetFiles();

                for (var c = 0; c < currentFiles.Length; c++)
                {
                    FileInfo toAdd = currentFiles[c];
                   
                    toSend.Add(toAdd);
                    
                }

            }

            return toSend;

        }

        public List<String> GetFlatFileListStrings(List<FileInfo> convertme, string excludeme)
        {
            List<String> toSend = new List<String>();

            for (int a = 0; a < convertme.Count; a++)
            {
                String toPut = convertme[a].FullName.Replace(excludeme, "");
                //Check if it's already there first?
                toSend.Add(toPut);
            }

            return toSend;
        }

        public void Search()
        {
            Search(lookinhere, lookforthis);
        }


        public void Search(string location, string term)
        {
            //System.IO.SearchOption.AllDirectories;

            //Get a flattened directory
            DirectoryInfo poop = new DirectoryInfo(location);
            List<DirectoryInfo> flatDirectory = new List<DirectoryInfo>();
            List<FileInfo> files = new List<FileInfo>();
            flatDirectory.Add(new DirectoryInfo(location));




            //For each item in the flat directory
            for (int a = 0; a < flatDirectory.Count; a++)
            {
                DirectoryInfo[] currentDirectories = flatDirectory[a].GetDirectories();

                //For each sub directory 
                for (int b = 0; b < currentDirectories.Length; b++)
                {
                    DirectoryInfo toAdd = currentDirectories[b];

                    //If it isn't already in there
                    if (flatDirectory.Contains(toAdd) == false)
                    {
                        flatDirectory.Add(currentDirectories[b]);

                    }
                }
            }

            //For each file in each folder

            for (int b = 0; b < flatDirectory.Count; b++)
            {
                FileInfo[] currentFiles = flatDirectory[b].GetFiles();

                for (var c = 0; c < currentFiles.Length; c++)
                {
                    FileInfo toAdd = currentFiles[c];
                    if (ValidFile(toAdd))
                    {
                        files.Add(toAdd);
                    }
                }

            }

            lastresults = "Searching for: \"" + lookforthis + "\" in " + lookinhere + Environment.NewLine + "------------------------------------------------------------------";

            //Read each file line by line
            for (int d = 0; d < files.Count; d++)
            {
                string rawresults = CheckForThis(files[d], lookforthis);

                if (rawresults.Length != 0)
                {
                    string result = files[d].FullName + " at lines: " + rawresults;
                    lastresults = lastresults + Environment.NewLine + result;

                }

            }

            Console.WriteLine(lastresults);




        }

        //Checks if a file has a particular string within.
        public string CheckForThis(FileInfo checkthis, string forthis)
        {
            string toSend = "";


            string leFile = checkthis.FullName;
            string ln = "";
            int lncurrent = 1;


            StreamReader truefile = new StreamReader(@leFile);

            while ((ln = truefile.ReadLine()) != null)
            {
                if (ln.ToLower().Contains(forthis.ToLower()))
                {
                    if (toSend.Length != 0) { toSend = toSend + ","; }

                    toSend = toSend + lncurrent.ToString();

                }

                lncurrent++;
            }

            truefile.Close();


            return toSend;
        }

        public List<String> ImportText (String lePath)
        {
            List<String> toSend = new List<String>();

            string ln = "";
            int lncurrent = 1;

            StreamReader truefile = new StreamReader(@lePath);

            while ((ln = truefile.ReadLine()) != null)
            {
                string toPut = ln;
                toSend.Add(ln);
            }
            truefile.Close();
            return toSend;
        }

        public String ImportAndCompareTextsString(String lePath1, String lePath2)
        {
            
            List<int> leList = ImportAndCompareTexts(lePath1, lePath2);

            //If there's nothing in there send NONE
            if (leList.Count == 1 && leList[0] == 0)
            {
                //IF you use this replace the NONE
                return NONE;
            }

            string toSend = "";

            //If there are different lines put this.
            if (leList.Count > 1)
            {
               toSend = "     Line";
            }

            if (leList.Count > 2)
            {
                toSend = toSend + "s";
            }

            toSend = toSend + " ";

            for (var a = 0; a < leList.Count; a++)
            {
                //Last element is the row count;
                if (a == leList.Count - 1 && leList[a] != 0)
                {
                    toSend = toSend + " Row Difference: " + leList[a] + "  line";
                    if (leList[a] > 1)
                    {
                        toSend = toSend + 's';
                    }
                }
                else if (a != leList.Count - 1)
                {
                    //Unless a is at the first element put a comma and space
                    if (a != 0)
                    {
                        toSend = toSend + " ,";
                    }

                    toSend = toSend + (leList[a] + 1);
                }
            }

            return toSend;
        }

        /// <summary>
        /// This compares 2 text files and returns the lines on which they differ. The very last entry in the list 
        /// contains the difference in lines
        /// </summary>
        /// <param name="lePath1"></param>
        /// <param name="lePath2"></param>
        /// <returns></returns>
        public List<int> ImportAndCompareTexts(String lePath1, String lePath2)
        {
            List<int> toSend = new List<int>();

            List<String> txt1 = ImportText(lePath1);
            List<String> txt2 = ImportText(lePath2);

            //If txt2 is shorter swap them.
            if (txt2.Count < txt1.Count)
            {
                List<String> extraParty = ImportText(lePath1);

                txt1 = txt2;
                txt2 = extraParty;
            }
            
            for (int a = 0; a < txt1.Count; a++)
            {
                //If the lines don't match indicate it.
                if (txt1[a] != txt2[a])
                {
                    int toPut = a;
                    toSend.Add(toPut);
                }
            }

            //Put the difference
            toSend.Add(Math.Abs(txt1.Count - txt2.Count));

            return toSend;
        }

        //Checks if the file's extension is not in the donotbother list.
        public bool ValidFile(FileInfo checkme)
        {


            string rawpath = checkme.FullName;
            string[] splitrawpath = rawpath.Split('.');
            string extension = splitrawpath[splitrawpath.Length - 1];

            if (donotbother.Contains(extension))
            {
                return false;
            }


            return true;
        }

        public bool ValidFile(String checkme)
        {
            string[] checkmesplit = checkme.Split('.');
            string extension = checkmesplit[checkmesplit.Length - 1];

            if (donotbother.Contains(extension))
            {
                return false;
            }

            return true;
        }

        //Iterates through the list one at a time
        public void ReadList(List<DirectoryInfo> poop)
        {
            for (var a = 0; a < poop.Count; a++)
            {
                Console.WriteLine(poop[a]);
            }
        }
        //Copy the results to the clipboard
        private void btnClipboard_Click(object sender, EventArgs e)
        {
            if (lastresults.Length == 0)
            {

            }
            else
            {
                Clipboard.SetText(lastresults);
                SetWin("Results copied to clipboard.");
            }
        }

        private void btnText_Click(object sender, EventArgs e)
        {

        }
        //https://stackoverflow.com/questions/11624298/how-to-use-openfiledialog-to-select-a-folder/11624322
        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog lefolder = new FolderBrowserDialog();
            lefolder.Description = "Choose Directory";


            if (lefolder.ShowDialog() == DialogResult.OK)
            {
                txtSearch.Text = lefolder.SelectedPath;
            }
        }

        //https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.savefiledialog?view=net-5.0
        private void SelectNewFile(object sender, EventArgs e)
        {
            SaveFileDialog lefile = new SaveFileDialog();
            lefile.Filter = "Text (*.txt)|*.txt";
            try
            {
                if (lefile.ShowDialog() == DialogResult.OK)
                {
                    string lePath = lefile.FileName;
                    string leContents = txtOutput.Text;

                    WriteFile(lePath, leContents);

                }
            } catch (Exception ex)
            {
                MessageBox.Show("Error:\n" + ex.Message);
            }


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnChoose1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog lefolder = new FolderBrowserDialog();
            lefolder.Description = "Choose Directory";


            if (lefolder.ShowDialog() == DialogResult.OK)
            {
                if (sender == btnChoose1)
                {
                    txtCompare1.Text = lefolder.SelectedPath;
                }
                else if (sender == btnChoose2)
                {
                    txtCompare2.Text = lefolder.SelectedPath;
                }
            }
        }

        private void btnCompare_Click(object sender, EventArgs e)
        {

            

            compareDir1 = txtCompare1.Text;
            compareDir2 = txtCompare2.Text;

            if (Directory.Exists(compareDir1) == false || Directory.Exists(compareDir2) == false || compareDir1.Length == 0 || compareDir2.Length == 0)
            {
                SetError("Please enter 2 valid file locations");
            }
            else
            {
                SetWin("Comparing...");
                Compare(compareDir1, compareDir2);
                txtOutput.Text = lastresults;
                SetClear();
            }

            lastresults = "";
        }
    }
}
